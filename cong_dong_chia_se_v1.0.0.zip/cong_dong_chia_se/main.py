#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Module Cộng Đồng Chia Sẻ
Tác giả: vnboy
Mô tả: Module lấy nội dung từ Google Sheets của cộng đồng chia sẻ
"""

import sys
import os
import xbmc
import xbmcgui
import xbmcaddon

# Thêm đường dẫn resources vào sys.path để import được các module cần thiết
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
resources_path = os.path.join(addon_path, 'resources')
if resources_path not in sys.path:
    sys.path.insert(0, resources_path)

try:
    from resources import cache_utils, gsheet
    from resources.addon import log, logError, addon_url
    import loadlistitem
except ImportError as e:
    xbmc.log(f"[Cộng Đồng Chia Sẻ] Lỗi import: {str(e)}", xbmc.LOGERROR)
    # Fallback functions
    def log(message):
        xbmc.log(f"[Cộng Đồng Chia Sẻ] {message}", xbmc.LOGINFO)
    def logError(message):
        xbmc.log(f"[Cộng Đồng Chia Sẻ] {message}", xbmc.LOGERROR)
    
    # Fallback addon_url
    addon_url = "plugin://plugin.video.vietmediaF/?"

# URL Google Sheets của cộng đồng chia sẻ
GOOGLE_SHEETS_URL = "https://docs.google.com/spreadsheets/d/1yCyQ1ZqIaeEkh5TYiXqPkTkRtrlbWkc6mL5jA2s6VqM/edit?gid=0#gid=0"

def get_community_content():
    """
    Lấy nội dung từ Google Sheets của cộng đồng chia sẻ
    
    Returns:
        dict: Dữ liệu đã được format theo chuẩn của VietMediaF
    """
    try:
        log("Bắt đầu lấy dữ liệu từ Cộng Đồng Chia Sẻ")
        
        # Sử dụng cache_utils để lấy dữ liệu từ Google Sheets
        # Tạo URL theo format mà handle_google_docs_url xử lý
        cache_url = f"{addon_url}url={GOOGLE_SHEETS_URL}"
        
        # Sử dụng cache_utils.cache_data để lấy dữ liệu
        data = cache_utils.cache_data(cache_url)
        
        if data is None:
            logError("Không thể lấy dữ liệu từ Google Sheets")
            return create_error_item()
        
        log(f"Đã lấy được {len(data.get('items', []))} mục từ Cộng Đồng Chia Sẻ")
        
        # Thêm thông tin module vào metadata
        if 'items' in data:
            for item in data['items']:
                # Thêm prefix để nhận biết đây là nội dung từ module
                if 'info' not in item:
                    item['info'] = {}
                item['info']['studio'] = 'Cộng Đồng Chia Sẻ'
                
        return data
        
    except Exception as e:
        logError(f"Lỗi khi lấy dữ liệu từ Cộng Đồng Chia Sẻ: {str(e)}")
        return create_error_item()

def create_error_item():
    """
    Tạo item thông báo lỗi khi không thể lấy dữ liệu
    
    Returns:
        dict: Dữ liệu chứa thông báo lỗi
    """
    return {
        "content_type": "movies",
        "items": [{
            'label': '[COLOR red]Lỗi kết nối[/COLOR]',
            'is_playable': False,
            'path': '',
            'thumbnail': '',
            'icon': '',
            'info': {
                'title': 'Lỗi kết nối',
                'plot': 'Không thể kết nối đến Google Sheets của Cộng Đồng Chia Sẻ. Vui lòng kiểm tra kết nối internet và thử lại.',
                'mediatype': 'movie'
            }
        }]
    }

def show_community_content():
    """
    Hiển thị nội dung từ cộng đồng chia sẻ
    Hàm này sẽ được gọi từ menu chính
    """
    try:
        log("Hiển thị nội dung Cộng Đồng Chia Sẻ")
        
        # Lấy dữ liệu
        data = get_community_content()
        
        # Hiển thị dữ liệu sử dụng loadlistitem
        if 'loadlistitem' in sys.modules:
            loadlistitem.list_item_main(data)
        else:
            # Fallback: hiển thị thông báo
            xbmcgui.Dialog().notification(
                'Cộng Đồng Chia Sẻ', 
                f'Đã tải {len(data.get("items", []))} mục', 
                xbmcgui.NOTIFICATION_INFO, 
                3000
            )
            
    except Exception as e:
        logError(f"Lỗi khi hiển thị nội dung: {str(e)}")
        xbmcgui.Dialog().notification(
            'Cộng Đồng Chia Sẻ', 
            'Có lỗi xảy ra khi tải nội dung', 
            xbmcgui.NOTIFICATION_ERROR, 
            5000
        )

# Entry point cho module
def main():
    """Entry point chính của module"""
    show_community_content()

# Để tương thích với các cách gọi khác nhau
if __name__ == "__main__":
    main()