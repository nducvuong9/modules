#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Sao chép nội dung từ tvhd.py sang main.py
from .tvhd import *
