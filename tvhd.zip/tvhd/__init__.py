# -*- coding: utf-8 -*-
"""
Tvhd Module for VietMediaF
Auto-upgraded by Module Manager on 2025-07-28 11:29:39
"""

__version__ = "1.1.0"
__author__ = "VietMediaF Team"
__module_name__ = "tvhd"

# Import main functionality
try:
    from .main import *
except ImportError:
    pass

# Import other module files dynamically
import os
current_dir = os.path.dirname(__file__)
try:
    for file in os.listdir(current_dir):
        if file.endswith('.py') and file not in ['__init__.py', 'main.py'] and not file.endswith('.backup'):
            module_file = file[:-3]  # Remove .py extension
            try:
                exec(f"from .{module_file} import *")
            except ImportError:
                pass
except Exception:
    pass

def get_module_info():
    """Trả về thông tin module"""
    return {
        "name": "tvhd",
        "display_name": "ThuVienHD",
        "description": "Module xem phim từ website thuvienhd",
        "version": "1.1.0"
    }

def handle_request():
    """Entry point chính - hiển thị menu của ThuVienHD"""
    try:
        # Import hàm receive từ tvhd
        from .tvhd import receive
        
        # Gọi receive với URL menu để hiển thị main menu
        menu_url = "https://thuvienhd.top/menu"
        data = receive(menu_url)
        
        # Import loadlistitem để hiển thị
        import loadlistitem
        loadlistitem.list_item_main(data)
        
    except Exception as e:
        import xbmc
        xbmc.log(f"[TVHD] Error in handle_request: {e}", xbmc.LOGERROR)
        try:
            from resources.addon import notify
            notify(f"Lỗi module ThuVienHD: {e}")
        except:
            pass

def main():
    """Alias cho handle_request"""
    handle_request()
